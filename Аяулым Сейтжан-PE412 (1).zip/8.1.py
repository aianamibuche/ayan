# name = "Daniyar,Almas,Abylay ar"
# print(name.upper())
# print(name.lower())
# print(name.find("Almas"))
# print(name.find("Nurlan"))
# print(name.find("ar"))

# fruit = "pineapple, orange, tomato"
# fruit.isalnum()
# fruit.isalpha()
# fruit.isdecimal()
# fruit.isdigit()
# fruit.islower()
# fruit.isupper()

# text = "Hello World! My name is Student."
# fruits = ["Apple", "Orange", "Grape"]
# print(text[::-1])
# print(fruits[::-1])

# Задание 1
text = input("Введите строку:")
print(text[::-1])

# Задание 2
text = input("Введите строку:")
print(text.swapcase())

# Задание 3
text = input("Введите строку:")
text2 = input("Введите подстроку:")
position = text.find(text2)
if position != -1:
    print("Подстрока найдена на позиции", position)
else:
    print("Подстрока не найдена")

# Задание 4
text = input("Введите строку:")
print("python" in text)

# Задание 5
text = input("Введите строку:")
symbol = input("Введите символ:")
print(text.count(symbol))

# Задание 6
text = input("Введите строку:")
if text == text[::-1]:
    print("Это палиндром")
else:
    print("Это не палиндром")

# Задание 7
text = input("Введите строку:")
symbol1 = input("Введите символ для замены: ")
symbol2 = input("Введите новый символ: ")
print(text.replace(symbol1, symbol2))

# Задание 8
text3 = input("Введите первую строку:")
text4 = input("Введите вторую строку:")
print(text3 == text4)

# Задание 9
text5 = input("Введите первую строку:")
text6 = input("Введите вторую строку:")
print(text5.lower() == text6.lower())

# Задание 10
text = input("Введите строку:")
print(text.isalpha())

# Задание 11
text = input("Введите строку:")
print(text.isalnum())

# Задание 12
text7 = input("Введите первую строку:")
text8 = input("Введите вторую строку:")
if len(text7) > len(text8):
    print("первая строка длиннее")
elif len(text7) < len(text8):
    print("вторая строка длиннее")
else:
    print("Обе строки одинаковой длины")
